
#include <iostream>
#include <cmath>
using namespace std;

int discriminante(int n)
{
	return 1 + 8*n;
}

bool isRaizEntero(long discriminanteInt)
{
	long raiz = sqrt(discriminanteInt);
	return (raiz * raiz) == discriminanteInt;
}

int calcularK(long n)
{
	long discriminanteInt = 1 + 8*n ;//discriminante(n);
	if(isRaizEntero(discriminanteInt))
	{
		long k = -1 + sqrt(discriminanteInt);
		if(k % 2 == 0)
		{
			return k / 2;
		}
	}
	return -1;
}

int main()
{
	cin.tie(0);
	ios_base::sync_with_stdio(0);
	int veces;
	long n;
	cin >> veces;
	for(int i = 0; i < veces; i++)
	{
		cin >> n;
		cout << calcularK(n) << "\n";
	}
	
	return 0;
}
