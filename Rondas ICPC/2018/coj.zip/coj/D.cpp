#include <iostream>
#include <string>
using namespace std;

int getValue(int pos){
	if(pos > 60){
		return pos-55;
		}
		else return pos - 48;
	}

int main()
{
	cin.tie(0);
	ios_base::sync_with_stdio(0);
	string n;
	long par, impar;
	bool pari;
	while(getline(cin,n)){
		par = 0;
		impar = 0;
		for(int i = 0; i < n.size() ; i++){
			if(i%2 == 0){
				par += getValue(n[i]);
				}
				else impar += getValue(n[i]);
			}
			impar -= par;
			if(impar < 0 ) impar *= -1;
			if (impar % 17 == 0) cout<<"yes\n";
			else cout<<"no"<<"\n";
		}
	return 0;
}
