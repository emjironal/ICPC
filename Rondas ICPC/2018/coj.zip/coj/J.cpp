#include <iostream>
using namespace std;

int main()
{
	cin.tie(0);
	ios_base::sync_with_stdio(0);
	
	int n, countSquares = 0;
	long min,sum;
	cin >> n;
	cin >> min;
	int matriz[n][n];
	//Agarra valiros de la matriz
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> matriz[i][j];
			sum += matriz[i][j];
			if(matriz[i][j] >= min)
				countSquares++;
		}
	}
	if(sum >= min && n > 1)
		countSquares++;
	else
		cout << 0;
		return 0;
	
	for(int dim = 2; dim < n ; dim ++)
	{
		for(int i = 0 ; i + dim <= n ; i++)
		{
			for(int j = 0; j + dim <= n; j++)			
			{
				sum = 0;
				for(int k = 0; k < dim ; k++)
				{
					for(int l = 0; l < dim ; l++)
					{
						sum += matriz[i+k][j+l];
						if(sum >= min){
							break;
							}
					}	
					if(sum >= min) break; 				
				}
				
				if(sum >= min)
					countSquares++;
			}
			
		}
	}
	cout << countSquares;
	return 0;
}
