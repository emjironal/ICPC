#include <iostream>
#include <string>
using namespace std;

int factorial( int largo, int rep)
{
	int res = 1;
	for(int i = largo ; i > rep ; i--){
		res = res * i;

		}
	return res;
	}

int main()
{
	cin.tie(0);
	ios_base::sync_with_stdio(0);
	int t,n;
	
	cin >> t;
	for(int i = 0; i < t ; i++){
		cin >> n;
		
		
		}

	return 0;
}
