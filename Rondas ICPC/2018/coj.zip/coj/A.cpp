#include <iostream>
using namespace std;

long factorial(int n)
{
	long result = 1;
	for(int i = 1; i <= n; i++)
	{
		result *= i;
	}
	return result;
}

int main()
{
	cin.tie(0);
	ios_base::sync_with_stdio(0);
	
	string n;
	int t;
	cin >> t;
	long aux, digFact, sumRepFact,sumat,result,resultado2;
	for(int i = 0; i < t ; i++)
	{
		cin >> n;
		
		int digitos[] = {0,0,0,0,0,0,0,0,0,0};
		
		for(int i = 0; i < n.size(); i++)
		{
			digitos[n[i] - 48]++;
		}
		
		digFact = factorial(n.size());
		sumRepFact = 0;
		for(int j = 0; j < 10; j++)
		{
			if(digitos[j] > 1)
				sumRepFact += factorial(digitos[j]);
		}
		if (sumRepFact == 0) sumRepFact = 1;
		result = digFact / sumRepFact;
		
		sumat = 0;
		for(int j = 0; j < n.size(); j++)
		{
			sumat+= n[j]-48;
		}
		aux = digFact / n.size();
		resultado2=0;
		for(int j = 1; j <= n.size(); j++){
			resultado2 += sumat*aux;
			aux *= 10;
		}
		resultado2 = resultado2 /sumRepFact;
		cout << result << " " << resultado2 << "\n";
	}
	
	return 0;
}
